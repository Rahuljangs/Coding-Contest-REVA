import csv
import glob
import os

database = open("D:\coding\\7q.csv")
csvreader = csv.reader(database)
databaseheader = []
databaseheader = next(csvreader)
datarows = []
for row in csvreader:

    datarows.append(row)
while 1:
    print("Select the operation\n1.Login\n2.Exit\n")
    choice = int(input())
    if choice == 1:
        print("Enter username : ")
        username = input()
        found = 0
        pssf = 0
        for row in datarows:
            for cell in row:
                if cell == username:
                    print("Enter password : ")
                    found = 1

                    password = input()
                    for row1 in datarows:
                        for cell1 in row1:
                            if cell1 == password:
                                print("The password is correct \n ")
                                userp = int(row1[2])
                                pssf = 1

                                if userp == 1:
                                    while 1:
                                        print("Select operaton\n1.Read\n2.Exit")
                                        choice2 = int(input())
                                        if choice2 == 1:
                                            print("The files that can be read are :")
                                            x = glob.glob("D:\coding\*")
                                            print(x)
                                            print(
                                                "To read any file among them, enter the complete directory of the file\n"
                                            )
                                            dr = input()
                                            file = open(dr, "r")
                                            print(file.read())
                                            file.close()
                                        if choice2 == 2:
                                            break

                                if userp == 2:
                                    print("The files that can be Written and Read are :")
                                    x = glob.glob("D:\coding\*")
                                    print(x)

                                    while 1:
                                        print("Select operation\n1.Read\n2.Write\n3.Exit")
                                        n = int(input())
                                        if n == 2:
                                            print(
                                                "To write any file among them, enter the complete directory of the file\n"
                                            )
                                            dr = input()
                                            file = open(dr, "a")
                                            print("Enter the content to be written \n")
                                            s = input()
                                            file.write(s)
                                            print("The file was written\n")
                                            file.close()
                                        if n == 1:
                                            print("The files that can be read are :")
                                            x = glob.glob("D:\coding\*")
                                            print(x)
                                            print(
                                                "To read any file among them, enter the complete directory of the file\n"
                                            )
                                            dr = input()
                                            file = open(dr, "r")
                                            print(file.read())
                                            file.close()
                                        if n == 3:
                                            break
                                if userp == 3:
                                    print("The files that can be Written and Read are :")
                                    x = glob.glob("D:\coding\*")
                                    print(x)
                                    while 1:
                                        print("Select operation\n1.Read\n2.Write\n3.Edit\n4.Exit")
                                        n = int(input())
                                        if n == 4:
                                            break
                                        if n == 2:
                                            print(
                                                "To write any file among them, enter the complete directory of the file\n"
                                            )
                                            dr = input()
                                            file = open(dr, "a")
                                            print("Enter the content to be written \n")
                                            s = input()
                                            file.write(s)
                                            print("The file was written\n")
                                            file.close()
                                        if n == 1:
                                            print("The files that can be read are :")
                                            x = glob.glob("D:\coding\*")
                                            print(x)
                                            print(
                                                "To read any file among them, enter the complete directory of the file\n"
                                            )
                                            dr = input()
                                            file = open(dr, "r")
                                            print(file.read())
                                            file.close()
                                        if n == 3:
                                            while 1:
                                                print("Select operation\n1.Replace\n2.Delete\n3.Exit from Edit mode\n")
                                                m = int(input())
                                                if m == 3:
                                                    break
                                                if m == 1:
                                                    print(
                                                        "To replace any file among them, enter the complete directory of the file\n"
                                                    )
                                                    dr = input()
                                                    file = open(dr, "w")
                                                    print("Enter the content to be replaced\n")
                                                    s = input()
                                                    file.write(s)
                                                    file.close()
                                                    print("The file was replaced\n")
                                                if m == 2:
                                                    print("Enter the path of the file to delete\n")
                                                    dr = input()
                                                    os.remove(dr)
                                                    print("The file was deleted\n")
                        if pssf == 0:
                            print("The password is incorrect\n")
                            break

        if found == 0:
            print("Username not found \n")

    if choice == 2:
        break

