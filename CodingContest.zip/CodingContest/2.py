import time

password = input("Enter the Password to be Registered : \n")

print("Enter N and M parameteres")

N = int(input())
M = int(input())

temp=N

while(N):
    
    login=input("Enter the Password to Login\n")
    if (login == password):
        print("The Password is Correct\n")
        break
    
    else :

        N = N - 1
        print("The Password is Incorrect\nTries left : {}".format(N))

        if(N==0):

            print("Please try after ", M, " Seconds")
            time.sleep(M)
            N = temp