from datetime import *
import time

now = datetime.today()
current_date = date.today()
current_time = now.strftime("%H:%M:%S")
print(current_time)
print("Enter the Task Name: ")
task = input()
print("Enter the Date in YY-MM-DD Format (Ex. 2021-12-2)\n")
clock_date = input()
print("Enter the Time in 24h Format (Ex. 12:00:00)\n")
clock_time = input()
s = str(current_date)
if int(clock_date[8:10]) == int(s[8:10]):
    if int(clock_time[0:2]) >= int(current_time[0:2]):
        total = (
            60 * 60 * (-int(current_time[0:2]) + int(clock_time[0:2]))
            + 60 * (-int(current_time[3:5]) + int(clock_time[3:5]))
            - int(current_time[6:9])
            + int(clock_time[6:9])
            + 60 * 60 * 24 * (int(clock_date[8:10]) - int(s[8:10]))
        )
        total = total - 5 * 60
        print("The countdown has started, seconds left ", total)
        time.sleep(total)
        print(task)
    else:
        print("Cannot Go back in Time")

else:
    if int(clock_date[8:10]) > int(s[8:10]):
        total = (
            60 * 60 * (-int(current_time[0:2]) + int(clock_time[0:2]))
            + 60 * (-int(current_time[3:5]) + int(clock_time[3:5]))
            - int(current_time[6:9])
            + int(clock_time[6:9])
            + 60 * 60 * 24 * (int(clock_date[8:10]) - int(s[8:10]))
        )
        total = total - 5 * 60
        print("The Countdown has Started, Seconds Left ", total)
        time.sleep(total)
        print(task)
    else:
        print("Cannot go back in time")

