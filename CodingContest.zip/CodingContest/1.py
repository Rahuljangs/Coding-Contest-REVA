def password_check(passwd):

    SpecialSym = ["/", " "]
    val = True

    if len(passwd) < 6:
        print("Password Length should be at least 6 ")
        val = False

    if len(passwd) > 20:
        print("length should be not be greater than 8")
        val = False

    if not any(char.isdigit() for char in passwd):
        print("Password should have at least one Numeric Digit")
        val = False

    if not any(char.isupper() for char in passwd):
        print("Password should contain at least one Uppercase Letter")
        val = False

    if not any(char.islower() for char in passwd):
        print("Password should contain at least one Lowercase Letter")
        val = False

    if any(char in SpecialSym for char in passwd):
        print("Password should not have a Slash (/) and or Space")
        val = False
    if val:
        return val


def main():
    passwd = input("Enter a Password : ")

    if password_check(passwd):
        print("Password is Valid")
    else:
        print("Invalid Password")


if __name__ == "__main__":
    main()

