import os
import subprocess
import shlex
import json
from functools import reduce
from operator import add
from collections import Counter
from pprint import pprint

FILENAME = "counters.json"
SCRIPTNAME = "11a.py"

try:
    os.remove(FILENAME)
except FileNotFoundError:
    pass
subprocess.check_call(shlex.split(f"scrapy runspider {SCRIPTNAME} -o {FILENAME}"))

with open(FILENAME) as fh:
    counts = (Counter(item) for item in json.load(fh))

# Add all the counters together.
pprint(reduce(add, counts), indent=4)
