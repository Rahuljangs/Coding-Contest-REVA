from collections import Counter

import scrapy


class QuotesSpider(scrapy.Spider):
    name = "quotes"
    start_urls = [
        "https://reva.edu.in/course/b.-tech-in-artificial-intelligence-and-data-science",
    ]

    def parse(self, response):
        for text in response.xpath("//body//*//text()").extract():
            # Eliminate empty strings
            words_ = (item.strip() for item in text.strip().split(" "))
            words = [item for item in words_ if item]
            if any(words):
                yield Counter(words)
